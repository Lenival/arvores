package br.ufrn.imd.controle;

public class ArvoreBinariaBuscaExtendida <T extends Comparable <T>> extends ArvoreBinariaBusca<T> {
	
/*
 *	TODO Implementar ArraList<NoBinarioEstendido<T>> que guardar� o n�s mais � esquerda de cada n�vel
 *	TODO Implementar fun��es de inser��o e remo��o que contemplem a atualiza��o
 * */
	
	

}
